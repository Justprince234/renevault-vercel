! function(a) {
    var t = function(e, r, o) {
        if (!(this instanceof t)) return new t(e, r, o);
        var s = window.slideshowcks || [];
        if (!(s.indexOf(e) > -1)) {
            s.push(e), window.slideshowcks = s;
            r = a.extend({}, {
                alignment: "center",
                autoAdvance: !0,
                mobileAutoAdvance: !0,
                barDirection: "leftToRight",
                barPosition: "bottom",
                cols: 6,
                easing: "easeInOutExpo",
                mobileEasing: "",
                fx: "random",
                mobileFx: "",
                gridDifference: 250,
                height: "50%",
                imagePath: "images/",
                hover: !0,
                loader: "pie",
                loaderColor: "#eeeeee",
                loaderBgColor: "#222222",
                loaderOpacity: .8,
                loaderPadding: 2,
                loaderStroke: 7,
                minHeight: "200px",
                navigation: !0,
                navigationHover: !0,
                mobileNavHover: !0,
                opacityOnGrid: !1,
                overlayer: !0,
                pagination: !0,
                playPause: !1,
                pauseOnClick: !0,
                pieDiameter: 38,
                piePosition: "rightTop",
                portrait: !1,
                rows: 4,
                slicedCols: 12,
                slicedRows: 8,
                slideOn: "random",
                thumbnails: !1,
                thumbheight: "100",
                thumbwidth: "75",
                time: 7e3,
                transPeriod: 1500,
                fullpage: !1,
                lightbox: "none",
                mobileimageresolution: 0,
                container: "",
                responsiveCaption: !1,
                keyboardNavigation: !1,
                onEndTransition: function() {},
                onLoaded: function() {},
                onStartLoading: function() {},
                onStartTransition: function() {}
            }, r);
            var n = a(e).addClass("camera_wrap");
            1 == r.fullpage ? (a(document.body).css("background", "none").prepend(n), n.css({
                height: "100%",
                "margin-left": 0,
                "margin-right": 0,
                "margin-top": 0,
                position: "fixed",
                visibility: "visible",
                left: 0,
                right: 0,
                top: 0,
                "min-width": "100%",
                "min-height": "100%",
                width: "100%",
                "z-index": "-1"
            })) : 0 != r.container && (a(r.container).css("background", "none").prepend('<div class="slideshowck_container_wrap"></div>'), a(".slideshowck_container_wrap", r.container).prepend(n), "relative" != a(r.container).css("position") && "absolute" != a(r.container).css("position") && a(r.container).css("position", "relative").css("z-index", "0"), n.parent(".slideshowck_container_wrap").css({
                height: "100%",
                "margin-left": 0,
                "margin-right": 0,
                "margin-top": 0,
                position: "absolute",
                visibility: "visible",
                left: 0,
                right: 0,
                "min-width": "100%",
                "min-height": "100%",
                width: "100%",
                overflow: "hidden",
                "z-index": "-1"
            })), n.wrapInner('<div class="camera_src" />').wrapInner('<div class="camera_fakehover" />');
            var c, l = a(".camera_fakehover", n);
            l.append('<div class="camera_target"></div>'), 1 == r.overlayer && l.append('<div class="camera_overlayer"></div>'), l.append('<div class="camera_target_content"></div>'), "pie" == (c = (navigator.userAgent.match(/MSIE 8.0/i) || navigator.userAgent.match(/MSIE 7.0/i) || navigator.userAgent.match(/MSIE 6.0/i)) && "none" != r.loader ? "bar" : r.loader) ? l.append('<div class="camera_pie"></div>') : "bar" == c ? l.append('<div class="camera_bar"></div>') : l.append('<div class="camera_bar" style="display:none"></div>'), 1 == r.playPause && l.append('<div class="camera_commands"></div>'), 1 == r.navigation && l.append('<div class="camera_prev" tabindex="0"><span></span></div>').append('<div class="camera_next" tabindex="0"><span></span></div>'), 1 == r.thumbnails && n.append('<div class="camera_thumbs_cont" />'), 1 == r.thumbnails && 1 != r.pagination && a(".camera_thumbs_cont", n).wrap("<div />").wrap('<div class="camera_thumbs" />').wrap("<div />").wrap('<div class="camera_command_wrap" />'), 1 == r.pagination && n.append('<div class="camera_pag"></div>'), n.append('<div class="camera_loader"></div>'), a(".camera_caption", n).each(function() {
                a(this).wrapInner("<div />")
            });
            var m = "pie_" + n.attr("id"),
                h = a(".camera_src", n),
                d = a(".camera_target", n),
                p = a(".camera_target_content", n),
                g = a(".camera_pie", n),
                u = a(".camera_bar", n),
                f = a(".camera_prev", n),
                v = a(".camera_next", n),
                b = a(".camera_commands", n),
                w = a(".camera_pag", n),
                y = a(".camera_thumbs_cont", n),
                _ = parseInt(a(document.body).width());
            if (imgresolution = 0, r.mobileimageresolution) {
                var x = r.mobileimageresolution.split(",");
                for (i = 0; i < x.length; i++) _ <= x[i] && (0 != imgresolution && x[i] <= imgresolution || 0 == imgresolution && _ < Math.max.apply(Math, x)) && (imgresolution = x[i])
            }
            var k, C = new Array;
            a("> div", h).each(function() {
                k = a(this).attr("data-src"), imgresolution && (imgsrctmp = k.split("/"), imgnametmp = imgsrctmp[imgsrctmp.length - 1], imgsrctmp[imgsrctmp.length - 1] = imgresolution + "/" + imgnametmp, k = imgsrctmp.join("/")), C.push(k)
            });
            var T = new Array,
                L = new Array,
                R = new Array;
            a("> div", h).each(function() {
                a(this).attr("data-link") ? T.push(a(this).attr("data-link")) : T.push(""), a(this).attr("data-rel") ? L.push('rel="' + a(this).attr("data-rel") + '" ') : L.push(""), a(this).attr("data-title") ? R.push('title="' + a(this).attr("data-title") + '" ') : R.push("")
            });
            var F = new Array;
            a("> div", h).each(function() {
                a(this).attr("data-target") ? F.push(a(this).attr("data-target")) : F.push("")
            });
            var S = new Array;
            a("> div", h).each(function() {
                a(this).attr("data-portrait") ? S.push(a(this).attr("data-portrait")) : S.push("")
            });
            var M = new Array;
            a("> div", h).each(function() {
                a(this).attr("data-alignment") ? M.push(a(this).attr("data-alignment")) : M.push("")
            });
            var B = new Array;
            a("> div", h).each(function() {
                a(this).attr("data-thumb") ? B.push(a(this).attr("data-thumb")) : B.push("")
            });
            var q, I = C.length;
            for (a(p).append('<div class="cameraContents" />'), q = 0; q < I; q++)
                if (a(".cameraContents", p).append('<div class="cameraContent" />'), "" != T[q]) {
                    var O = a("> div ", h).eq(q).attr("data-box");
                    O = void 0 !== O && !1 !== O && "" != O ? 'data-box="' + a("> div ", h).eq(q).attr("data-box") + '"' : "", a(".camera_target_content .cameraContent:eq(" + q + ")", n).append('<a class="camera_link" ' + L[q] + R[q] + 'href="' + T[q] + '" ' + O + ' target="' + F[q] + '"></a>')
                }
            var H = new Array;
            a(".camera_caption", n).each(function() {
                var t = a(this).parent().index(),
                    e = n.find(".cameraContent").eq(t),
                    i = a(this).find(".camera_caption_title").text().trim(),
                    r = a(this).find(".camera_caption_desc").text().trim(),
                    o = i.length ? i : r || C[t];
                H.push(o), a(this).appendTo(e)
            }), d.append('<div class="cameraCont" />');
            var W, A, P = a(".cameraCont", n);
            for (W = 0; W < I; W++) {
                P.append('<div class="cameraSlide cameraSlide_' + W + '" />');
                var z = a("> div:eq(" + W + ")", h);
                d.find(".cameraSlide_" + W).clone(z)
            }
            a(window).bind("load resize pageshow", function() {
                var t;
                xa(), va(), r.responsiveCaption && (t = n.width() / 700, a(".camera_caption > div").css("font-size", t + "em"))
            }), a(window).bind("cameraupdate", function() {
                ba(), a(window).trigger("resize")
            }), P.append('<div class="cameraSlide cameraSlide_' + W + '" />'), n.show();
            var E, D, N, G, j, Q, X, Y = d.width(),
                $ = d.height();
            if (a(window).bind("resize pageshow", function() {
                    1 == A && ya(), a("ul", y).animate({
                        "margin-top": 0
                    }, 0, xa), h.hasClass("paused") || (h.addClass("paused"), a(".camera_stop", U).length ? (a(".camera_stop", U).hide(), a(".camera_play", U).show(), "none" != c && a("#" + m).hide()) : "none" != c && a("#" + m).hide(), clearTimeout(E), E = setTimeout(function() {
                        h.removeClass("paused"), a(".camera_play", U).length ? (a(".camera_play", U).hide(), a(".camera_stop", U).show(), "none" != c && a("#" + m).fadeIn()) : "none" != c && a("#" + m).fadeIn()
                    }, 1500))
                }), wa(), 0 == (G = fa() && "" != r.mobileAutoAdvance ? r.mobileAutoAdvance : r.autoAdvance) && h.addClass("paused"), j = fa() && "" != r.mobileNavHover ? r.mobileNavHover : r.navigationHover, 0 != h.length) {
                var J = a(".cameraSlide", d);
                J.wrapInner('<div class="camerarelative" />');
                var K = r.barDirection,
                    U = n;

                function V() {
                    a("iframe", l).each(function() {
                        a(".camera_caption", l).show();
                        var t = a(this),
                            e = t.attr("data-src");
                        t.attr("src", e);
                        var i = r.imagePath + "blank.gif",
                            o = new Image;
                        o.src = i, wa(), t.after(a(o).attr({
                            class: "imgFake",
                            width: Y,
                            height: $
                        }));
                        var s = t.clone();
                        t.remove(), a(o).bind("click", function() {
                            "absolute" == a(this).css("position") ? (a(this).remove(), autoplay = "", -1 != e.indexOf("vimeo") || -1 != e.indexOf("youtube") ? -1 != e.indexOf("?") ? autoplay = "&autoplay=1" : autoplay = "?autoplay=1" : -1 != e.indexOf("dailymotion") && (-1 != e.indexOf("?") ? autoplay = "&autoPlay=1" : autoplay = "?autoPlay=1"), s.attr("src", e + autoplay), X = !0) : (a(this).css({
                                position: "absolute",
                                top: 0,
                                left: 0,
                                zIndex: 10
                            }).after(s), s.css({
                                position: "absolute",
                                top: 0,
                                left: 0,
                                zIndex: 9
                            }))
                        })
                    })
                }

                function Z() {
                    G = !0, h.removeClass("paused"), a(".camera_play", U).length ? (a(".camera_play", U).hide(), a(".camera_stop", U).show(), "none" != c && a("#" + m).show()) : "none" != c && a("#" + m).show()
                }

                function aa() {
                    G = !1, h.addClass("paused"), a(".camera_stop", U).length ? (a(".camera_stop", U).hide(), a(".camera_play", U).show(), "none" != c && a("#" + m).hide()) : "none" != c && a("#" + m).hide()
                }
                a("iframe", l).each(function() {
                    var t = a(this),
                        e = t.attr("src");
                    t.attr("data-src", e);
                    var i = t.parent().index("#" + n.attr("id") + " .camera_src > div");
                    a(".camera_target_content .cameraContent:eq(" + i + ")", n).append(t)
                }), V(), 1 == r.hover && (fa() || "kenburns" == r.fx || l.hover(function() {
                    h.addClass("hovered")
                }, function() {
                    h.removeClass("hovered")
                })), 1 == j && (a(f, n).animate({
                    opacity: 0
                }, 0), a(v, n).animate({
                    opacity: 0
                }, 0), a(b, n).animate({
                    opacity: 0
                }, 0), fa() ? (l.on("vmouseover", function() {
                    a(f, n).animate({
                        opacity: 1
                    }, 200), a(v, n).animate({
                        opacity: 1
                    }, 200), a(b, n).animate({
                        opacity: 1
                    }, 200)
                }), l.on("vmouseout", function() {
                    a(f, n).delay(500).animate({
                        opacity: 0
                    }, 200), a(v, n).delay(500).animate({
                        opacity: 0
                    }, 200), a(b, n).delay(500).animate({
                        opacity: 0
                    }, 200)
                })) : l.hover(function() {
                    a(f, n).animate({
                        opacity: 1
                    }, 200), a(v, n).animate({
                        opacity: 1
                    }, 200), a(b, n).animate({
                        opacity: 1
                    }, 200)
                }, function() {
                    a(f, n).animate({
                        opacity: 0
                    }, 200), a(v, n).animate({
                        opacity: 0
                    }, 200), a(b, n).animate({
                        opacity: 0
                    }, 200)
                })), U.on("click keypress", ".camera_stop", function(a) {
                    ("keypress" == a.type && 13 == a.which || "click" == a.type) && aa()
                }), U.on("click keypress", ".camera_play", function(a) {
                    ("keypress" == a.type && 13 == a.which || "click" == a.type) && Z()
                }), 1 == r.keyboardNavigation && a(document).keydown(function(t) {
                    var e, i, r, o, s;
                    (37 == t.which || 39 == t.which || 80 == t.which) && (e = a(window), i = e.scrollTop(), r = n.offset().top, o = r + n.height() / 2 > i, s = r + n.height() / 2 < i + e.height(), o && s) && ("keydown" == t.type && 37 == t.which && Ta(), "keydown" == t.type && 39 == t.which && La(), "keydown" == t.type && 80 == t.which && (h.hasClass("paused") ? Z() : aa()))
                }), 1 == r.pauseOnClick && a(".camera_target_content", l).mouseup(function() {
                    G = !1, h.addClass("paused"), a(".camera_stop", U).hide(), a(".camera_play", U).show(), a("#" + m).hide()
                }), a(".cameraContent, .imgFake", l).hover(function() {
                    Q = !0
                }, function() {
                    Q = !1
                }), a(".cameraContent, .imgFake", l).bind("click", function() {
                    1 == X && 1 == Q && (G = !1, a(".camera_caption", l).hide(), h.addClass("paused"), a(".camera_stop", U).hide(), a(".camera_play", U).show(), a("#" + m).hide())
                })
            }
            if ("pie" != c) {
                switch (u.append('<span class="camera_bar_cont" />'), a(".camera_bar_cont", u).animate({
                    opacity: r.loaderOpacity
                }, 0).css({
                    position: "absolute",
                    left: 0,
                    right: 0,
                    top: 0,
                    bottom: 0,
                    "background-color": r.loaderBgColor
                }).append('<span id="' + m + '" />'), a("#" + m).animate({
                    opacity: 0
                }, 0), (ta = a("#" + m)).css({
                    position: "absolute",
                    "background-color": r.loaderColor
                }), r.barPosition) {
                    case "left":
                        u.css({
                            right: "auto",
                            width: r.loaderStroke
                        });
                        break;
                    case "right":
                        u.css({
                            left: "auto",
                            width: r.loaderStroke
                        });
                        break;
                    case "top":
                        u.css({
                            bottom: "auto",
                            height: r.loaderStroke
                        });
                        break;
                    case "bottom":
                        u.css({
                            top: "auto",
                            height: r.loaderStroke
                        })
                }
                switch (K) {
                    case "leftToRight":
                    case "rightToLeft":
                        ta.css({
                            left: 0,
                            right: 0,
                            top: r.loaderPadding,
                            bottom: r.loaderPadding
                        });
                        break;
                    case "topToBottom":
                    case "bottomToTop":
                        ta.css({
                            left: r.loaderPadding,
                            right: r.loaderPadding,
                            top: 0,
                            bottom: 0
                        })
                }
            } else {
                var ta, ea, ia, ra;
                switch (g.append('<canvas id="' + m + '"></canvas>'), (ta = document.getElementById(m)).setAttribute("width", r.pieDiameter), ta.setAttribute("height", r.pieDiameter), r.piePosition) {
                    case "leftTop":
                        ea = "left:0; top:0;";
                        break;
                    case "rightTop":
                        ea = "right:0; top:0;";
                        break;
                    case "leftBottom":
                        ea = "left:0; bottom:0;";
                        break;
                    case "rightBottom":
                        ea = "right:0; bottom:0;"
                }
                if (ta.setAttribute("style", "position:absolute; z-index:1002; " + ea), ta && ta.getContext) {
                    var oa = ta.getContext("2d");
                    oa.rotate(1.5 * Math.PI), oa.translate(-r.pieDiameter, 0)
                }
            }
            if ("none" != c && 0 != G || (a("#" + m).hide(), a(".camera_canvas_wrap", U).hide()), a(w).length) {
                var sa;
                for (a(w).append('<ul class="camera_pag_ul" />'), sa = 0; sa < I; sa++) a(".camera_pag_ul", n).append('<li class="pag_nav_' + sa + '" style="position:relative; z-index:1002" tabindex="0" aria-label="Show slide ' + (sa + 1) + '"><span><span>' + sa + "</span></span></li>");
                a(".camera_pag_ul li", n).hover(function() {
                    if (a(this).addClass("camera_hover"), a(".camera_thumb", this).length) {
                        var t = a(".camera_thumb", this).outerWidth(),
                            e = a(".camera_thumb", this).outerHeight(),
                            i = a(this).outerWidth();
                        a(".camera_thumb", this).show().css({
                            top: "-" + e + "px",
                            left: "-" + (t - i) / 2 + "px"
                        }).animate({
                            opacity: 1,
                            "margin-top": "-3px"
                        }, 200), a(".thumb_arrow", this).show().animate({
                            opacity: 1,
                            "margin-top": "-3px"
                        }, 200)
                    }
                }, function() {
                    a(this).removeClass("camera_hover"), a(".camera_thumb", this).animate({
                        "margin-top": "-20px",
                        opacity: 0
                    }, 200, function() {
                        a(this).css({
                            marginTop: "5px"
                        }).hide()
                    }), a(".thumb_arrow", this).animate({
                        "margin-top": "-20px",
                        opacity: 0
                    }, 200, function() {
                        a(this).css({
                            marginTop: "5px"
                        }).hide()
                    })
                })
            }
            r.onStartLoading.call(this), Ca(), a(y).length ? a(w).length ? (a.each(B, function(t, e) {
                if ("" != a("> div", h).eq(t).attr("data-thumb")) {
                    var i = a("> div", h).eq(t).attr("data-thumb"),
                        r = new Image;
                    r.src = i, a("li.pag_nav_" + t, w).append(a(r).attr("class", "camera_thumb").css({
                        position: "absolute"
                    }).animate({
                        opacity: 0
                    }, 0)), a("li.pag_nav_" + t + " > img", w).after('<div class="thumb_arrow" />'), a("li.pag_nav_" + t + " > .thumb_arrow", w).animate({
                        opacity: 0
                    }, 0)
                }
            }), n.css({
                marginBottom: a(w).outerHeight()
            })) : (a(y).append("<div />"), a(y).before('<div class="camera_prevThumbs hideNav"><div></div></div>').before('<div class="camera_nextThumbs hideNav"><div></div></div>'), a("> div", y).append("<ul />"), a("ul", y).width(B.length * (parseInt(r.thumbwidth) + 2)), a("ul", y).height(parseInt(r.thumbheight)), ulthumbwidth = 0, a.each(B, function(t, e) {
                if ("" != a("> div", h).eq(t).attr("data-thumb")) {
                    var i = a("> div", h).eq(t).attr("data-thumb"),
                        r = new Image;
                    r.src = i, a("ul", y).append('<li class="pix_thumb pix_thumb_' + t + '" />'), a("li.pix_thumb_" + t, y).append(a(r).attr("class", "camera_thumb")), ulthumbwidth += parseFloat(a("li.pix_thumb_" + t, y).outerWidth()) + parseFloat(a("li.pix_thumb_" + t, y).css("marginLeft")) + parseFloat(a("li.pix_thumb_" + t, y).css("marginRight"))
                }
            }), a("ul", y).width(ulthumbwidth)) : !a(y).length && a(w).length && n.css({
                marginBottom: a(w).outerHeight()
            });
            var na = !0;
            a(b).length && (a(b).append('<div class="camera_play" tabindex="0" aria-label="Start the slideshow"></div>').append('<div class="camera_stop" tabindex="0" aria-label="Pause the slideshow"></div>'), 1 == G ? (a(".camera_play", U).hide(), a(".camera_stop", U).show()) : (a(".camera_stop", U).hide(), a(".camera_play", U).show())), ka(), a(".moveFromLeft, .moveFromRight, .moveFromTop, .moveFromBottom, .fadeIn, .fadeFromLeft, .fadeFromRight, .fadeFromTop, .fadeFromBottom", l).each(function() {
                a(this).css("visibility", "hidden")
            }), "mediaboxck" == r.lightbox && "undefined" != typeof Mediabox ? Mediabox.scanPage() : "squeezebox" == r.lightbox && "undefined" != typeof SqueezeBox && (SqueezeBox.initialize({}), SqueezeBox.assign($$("a.camera_link[rel=lightbox]"), {})), a(f).length && a(f).on("click keypress", function(a) {
                ("keypress" == a.type && 13 == a.which || "click" == a.type) && Ta()
            }), a(v).length && a(v).on("click keypress", function(a) {
                ("keypress" == a.type && 13 == a.which || "click" == a.type) && La()
            });
            var ca = 0,
                la = 0,
                ma = 0,
                ha = 0,
                da = 0,
                pa = 72,
                ga = null,
                ua = null;
            fa() && (l[0].addEventListener("touchstart", function(a) {
                1 == (ca = a.touches.length) ? (la = a.touches[0].pageX, ma = a.touches[0].pageY, "") : Ra()
            }, !1), l[0].addEventListener("touchmove", function(a) {
                1 == a.touches.length ? (ha = a.touches[0].pageX, da = a.touches[0].pageY) : Ra()
            }, !1), l[0].addEventListener("touchend", function(t) {
                var e, i, o;
                1 == ca && 0 != ha && Math.round(Math.sqrt(Math.pow(ha - la, 2) + Math.pow(da - ma, 2))) >= pa ? (e = la - ha, i = da - ma, Math.round(Math.sqrt(Math.pow(e, 2) + Math.pow(i, 2))), o = Math.atan2(i, e), (ga = Math.round(180 * o / Math.PI)) < 0 && (ga = 360 - Math.abs(ga)), ua = ga <= 45 && ga >= 0 ? "left" : ga <= 360 && ga >= 315 ? "left" : ga >= 135 && ga <= 225 ? "right" : ga > 45 && ga < 135 ? "down" : "up", function() {
                    if ("left" == ua) {
                        if (!h.hasClass("camerasliding")) {
                            var t = parseFloat(a(".cameraSlide.cameracurrent", d).index());
                            clearInterval(D), V(), a("#" + m + ", .camera_canvas_wrap", U).animate({
                                opacity: 0
                            }, 0), ka(), Ca(t == I - 1 ? 1 : t + 2), r.onStartLoading.call(this)
                        }
                    } else if ("right" == ua && !h.hasClass("camerasliding")) {
                        var t = parseFloat(a(".cameraSlide.cameracurrent", d).index());
                        clearInterval(D), V(), a("#" + m + ", .camera_canvas_wrap", U).animate({
                            opacity: 0
                        }, 0), ka(), Ca(0 != t ? t : I), r.onStartLoading.call(this)
                    }
                }(), Ra()) : Ra()
            }, !1), l[0].addEventListener("touchcancel", Ra, !1)), a(w).length && a(".camera_pag li", n).on("click keypress", function(t) {
                if (("keypress" == t.type && 13 == t.which || "click" == t.type) && !h.hasClass("camerasliding")) {
                    var e = parseFloat(a(this).index());
                    e != parseFloat(a(".cameraSlide.cameracurrent", d).index()) && (clearInterval(D), V(), a("#" + m + ", .camera_canvas_wrap", U).animate({
                        opacity: 0
                    }, 0), ka(), Ca(e + 1), r.onStartLoading.call(this))
                }
            }), a(y).length && (a(".pix_thumb img", y).click(function() {
                if (!h.hasClass("camerasliding")) {
                    var t = parseFloat(a(this).parents("li").index());
                    t != parseFloat(a(".cameracurrent", d).index()) && (clearInterval(D), V(), a("#" + m + ", .camera_canvas_wrap", U).animate({
                        opacity: 0
                    }, 0), a(".pix_thumb", y).removeClass("cameracurrent"), a(this).parents("li").addClass("cameracurrent"), ka(), Ca(t + 1), xa(), r.onStartLoading.call(this))
                }
            }), a(".camera_thumbs_cont .camera_prevThumbs", U).hover(function() {
                a(this).stop(!0, !1).animate({
                    opacity: 1
                }, 250)
            }, function() {
                a(this).stop(!0, !1).animate({
                    opacity: .7
                }, 250)
            }), a(".camera_prevThumbs", U).click(function() {
                var t = 0,
                    e = (a(y).outerWidth(), a("ul", y).offset().left),
                    i = a("> div", y).offset().left - e;
                a(".camera_visThumb", y).each(function() {
                    var e = a(this).outerWidth();
                    t += e
                }), i - t > 0 ? a("ul", y).animate({
                    "margin-left": "-" + (i - t) + "px"
                }, 500, va) : a("ul", y).animate({
                    "margin-left": 0
                }, 500, va)
            }), a(".camera_thumbs_cont .camera_nextThumbs", U).hover(function() {
                a(this).stop(!0, !1).animate({
                    opacity: 1
                }, 250)
            }, function() {
                a(this).stop(!0, !1).animate({
                    opacity: .7
                }, 250)
            }), a(".camera_nextThumbs", U).click(function() {
                var t = 0,
                    e = a(y).outerWidth(),
                    i = a("ul", y).outerWidth(),
                    r = a("ul", y).offset().left,
                    o = a("> div", y).offset().left - r;
                a(".camera_visThumb", y).each(function() {
                    var e = a(this).outerWidth();
                    t += e
                }), o + t + t < i ? a("ul", y).animate({
                    "margin-left": "-" + (o + t) + "px"
                }, 500, va) : a("ul", y).animate({
                    "margin-left": "-" + (i - e) + "px"
                }, 500, va)
            }))
        }

        function fa() {
            if (navigator.userAgent.match(/Android/i) || navigator.userAgent.match(/webOS/i) || navigator.userAgent.match(/iPad/i) || navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPod/i)) return !0
        }

        function va() {
            ba();
            var t = a(y).width();
            a("li", y).removeClass("camera_visThumb"), a("li", y).each(function() {
                var e = a(this).position(),
                    i = (a("ul", y).outerWidth(), a("ul", y).offset().left),
                    r = a("> div", y).offset().left - i;
                a(".camera_prevThumbs", U).removeClass("hideNav").css("visibility", "visible"), a(".camera_nextThumbs", U).removeClass("hideNav").css("visibility", "visible");
                var o = e.left;
                e.left + a(this).width() - r <= t && o - r >= 0 && a(this).addClass("camera_visThumb")
            })
        }

        function ba() {
            a("ul", y).width(B.length * (parseInt(r.thumbwidth) + 20))
        }

        function wa() {
            if (Y = n.width(), -1 != r.height.indexOf("%")) {
                var t = Math.round(Y / (100 / parseFloat(r.height)));
                $ = "" != r.minHeight && t < parseFloat(r.minHeight) ? parseFloat(r.minHeight) : t, n.css({
                    height: $
                })
            } else "auto" == r.height ? $ = n.height() : ($ = parseFloat(r.height), n.css({
                height: $
            }));
            1 == r.fullpage ? ($ = a(window).height(), n.css({
                height: $
            })) : 0 != r.container && ($ = a(r.container).height()), n.css({
                height: $
            })
        }

        function ya() {
            var t;

            function e() {
                Y = n.width(), wa(), a(".camerarelative", d).css({
                    width: Y,
                    height: $
                }), a(".imgLoaded", d).each(function() {
                    var t, e, i = a(this),
                        o = i.attr("width"),
                        s = i.attr("height"),
                        n = (i.index(), i.attr("data-alignment")),
                        c = i.attr("data-portrait");
                    if ("kenburns" == r.fx) i.css({
                        position: "absolute",
                        visibility: "visible"
                    });
                    else if (void 0 !== n && !1 !== n && "" !== n || (n = r.alignment), void 0 !== c && !1 !== c && "" !== c || (c = r.portrait), 1 == r.fullpage) {
                        var l = s / o,
                            m = (p = a(window).height()) / (g = a(window).width()),
                            h = Y / o,
                            d = .5 * Math.abs($ - s * h);
                        switch (n) {
                            case "topLeft":
                            case "topCenter":
                            case "topRight":
                                t = 0;
                                break;
                            case "centerLeft":
                            case "center":
                            case "centerRight":
                                t = "-" + d + "px";
                                break;
                            case "bottomLeft":
                            case "bottomCenter":
                            case "bottomRight":
                                t = "-" + 2 * d + "px"
                        }
                        m > l ? (imgH = p - 2 * parseInt(t), imgW = imgH / l, e = Math.abs((g - imgW) / 2)) : (imgW = g, imgH = imgW * l, e = 0), i.css({
                            height: imgH,
                            "margin-left": -e,
                            "margin-right": -e,
                            "margin-top": t,
                            position: "absolute",
                            visibility: "visible",
                            left: 0,
                            top: 0,
                            width: imgW
                        })
                    } else if (0 != r.container) {
                        var p, g;
                        l = s / o;
                        t = 0, (m = (p = a(r.container).height()) / (g = a(r.container).width())) > l ? (imgH = p, imgW = imgH / l, e = Math.abs((g - imgW) / 2), t = 0) : (imgW = g, imgH = imgW * l, e = 0, t = 0), i.css({
                            height: imgH,
                            "margin-left": -e,
                            "margin-right": -e,
                            "margin-top": t,
                            position: "absolute",
                            visibility: "visible",
                            left: 0,
                            top: 0,
                            width: imgW
                        })
                    } else if (0 == c || "false" == c)
                        if (o / s < Y / $) {
                            h = Y / o, d = .5 * Math.abs($ - s * h);
                            switch (n) {
                                case "topLeft":
                                case "topCenter":
                                case "topRight":
                                    t = 0;
                                    break;
                                case "centerLeft":
                                case "center":
                                case "centerRight":
                                    t = "-" + d + "px";
                                    break;
                                case "bottomLeft":
                                case "bottomCenter":
                                case "bottomRight":
                                    t = "-" + 2 * d + "px"
                            }
                            i.css({
                                height: s * h,
                                "margin-left": 0,
                                "margin-right": 0,
                                "margin-top": t,
                                position: "absolute",
                                visibility: "visible",
                                width: Y
                            })
                        } else {
                            h = $ / s, d = .5 * Math.abs(Y - o * h);
                            switch (n) {
                                case "topLeft":
                                    e = 0;
                                    break;
                                case "topCenter":
                                    e = "-" + d + "px";
                                    break;
                                case "topRight":
                                    e = "-" + 2 * d + "px";
                                    break;
                                case "centerLeft":
                                    e = 0;
                                    break;
                                case "center":
                                    e = "-" + d + "px";
                                    break;
                                case "centerRight":
                                    e = "-" + 2 * d + "px";
                                    break;
                                case "bottomLeft":
                                    e = 0;
                                    break;
                                case "bottomCenter":
                                    e = "-" + d + "px";
                                    break;
                                case "bottomRight":
                                    e = "-" + 2 * d + "px"
                            }
                            i.css({
                                height: $,
                                "margin-left": e,
                                "margin-right": e,
                                "margin-top": 0,
                                position: "absolute",
                                visibility: "visible",
                                width: o * h
                            })
                        }
                    else if (o / s < Y / $) {
                        h = $ / s, d = .5 * Math.abs(Y - o * h);
                        switch (n) {
                            case "topLeft":
                                e = 0;
                                break;
                            case "topCenter":
                                e = d + "px";
                                break;
                            case "topRight":
                                e = 2 * d + "px";
                                break;
                            case "centerLeft":
                                e = 0;
                                break;
                            case "center":
                                e = d + "px";
                                break;
                            case "centerRight":
                                e = 2 * d + "px";
                                break;
                            case "bottomLeft":
                                e = 0;
                                break;
                            case "bottomCenter":
                                e = d + "px";
                                break;
                            case "bottomRight":
                                e = 2 * d + "px"
                        }
                        i.css({
                            height: $,
                            "margin-left": e,
                            "margin-right": e,
                            "margin-top": 0,
                            position: "absolute",
                            visibility: "visible",
                            width: o * h
                        })
                    } else {
                        h = Y / o, d = .5 * Math.abs($ - s * h);
                        switch (n) {
                            case "topLeft":
                            case "topCenter":
                            case "topRight":
                                t = 0;
                                break;
                            case "centerLeft":
                            case "center":
                            case "centerRight":
                                t = d + "px";
                                break;
                            case "bottomLeft":
                            case "bottomCenter":
                            case "bottomRight":
                                t = 2 * d + "px"
                        }
                        i.css({
                            height: s * h,
                            "margin-left": 0,
                            "margin-right": 0,
                            "margin-top": t,
                            position: "absolute",
                            visibility: "visible",
                            width: Y
                        })
                    }
                })
            }
            1 == A ? (clearTimeout(t), t = setTimeout(e, 200)) : e(), A = !0
        }

        function _a(a) {
            for (var t, e, i = a.length; i; t = parseInt(Math.random() * i), e = a[--i], a[i] = a[t], a[t] = e);
            return a
        }

        function xa() {
            if (a(y).length && !a(w).length) {
                var t, e = a(y).outerWidth(),
                    i = (a("ul > li", y).outerWidth(), a("li.cameracurrent", y).length ? a("li.cameracurrent", y).position() : ""),
                    r = a("ul > li", y).length * a("ul > li", y).outerWidth(),
                    o = a("ul", y).offset().left,
                    s = a("> div", y).offset().left;
                t = o < 0 ? "-" + (s - o) : s - o, 1 == na && (ulthumbwidth = 0, a.each(B, function(t, e) {
                    ulthumbwidth += parseFloat(a("li.pix_thumb_" + t, y).outerWidth()) + parseFloat(a("li.pix_thumb_" + t, y).css("marginLeft")) + parseFloat(a("li.pix_thumb_" + t, y).css("marginRight"))
                }), a("ul", y).width(ulthumbwidth + 2), a(y).length && !a(w).lenght && n.css({
                    marginBottom: a(y).outerHeight()
                }), va(), a(y).length && !a(w).lenght && n.css({
                    marginBottom: a(y).outerHeight()
                })), na = !1;
                var c = a("li.cameracurrent", y).length ? i.left : "",
                    l = a("li.cameracurrent", y).length ? i.left + a("li.cameracurrent", y).outerWidth() : "";
                c < a("li.cameracurrent", y).outerWidth() && (c = 0), l - t > e ? c + e < r ? a("ul", y).animate({
                    "margin-left": "-" + c + "px"
                }, 500, va) : a("ul", y).animate({
                    "margin-left": "-" + (a("ul", y).outerWidth() - e) + "px"
                }, 500, va) : c - t < 0 ? a("ul", y).animate({
                    "margin-left": "-" + c + "px"
                }, 500, va) : (a("ul", y).css({
                    "margin-left": "auto",
                    "margin-right": "auto"
                }), setTimeout(va, 100))
            }
        }

        function ka() {
            ia = 0;
            var t = a(".camera_bar_cont", U).width(),
                e = a(".camera_bar_cont", U).height();
            if ("pie" != c) switch (K) {
                case "leftToRight":
                    a("#" + m).css({
                        right: t
                    });
                    break;
                case "rightToLeft":
                    a("#" + m).css({
                        left: t
                    });
                    break;
                case "topToBottom":
                    a("#" + m).css({
                        bottom: e
                    });
                    break;
                case "bottomToTop":
                    a("#" + m).css({
                        top: e
                    })
            } else oa.clearRect(0, 0, r.pieDiameter, r.pieDiameter)
        }

        function Ca(t) {
            h.addClass("camerasliding"), X = !1;
            var e = parseFloat(a("div.cameraSlide.cameracurrent", d).index());
            if (t > 0) var i = t - 1;
            else if (e == I - 1) i = 0;
            else i = e + 1;
            var o = a(".cameraSlide:eq(" + i + ")", d),
                s = a(".cameraSlide:eq(" + (i + 1) + ")", d).addClass("cameranext");
            if (e != i + 1 && s.hide(), a(".cameraContent", l).fadeOut(600), a(".camera_caption", l).show(), a(".camerarelative", o).append(a("> div ", h).eq(i).find("> div.camera_effected")), a(".camera_target_content .cameraContent:eq(" + i + ")", n).append(a("> div ", h).eq(i).find("> div")), a(".imgLoaded", o).length) {
                if (C.length > i + 1 && !a(".imgLoaded", s).length) {
                    var p = C[i + 1],
                        g = new Image;
                    g.src = p, s.prepend(a(g).attr("class", "imgLoaded").css("visibility", "hidden")), g.onload = function() {
                        da = g.naturalWidth, pa = g.naturalHeight, a(g).attr("data-alignment", M[i + 1]).attr("data-portrait", S[i + 1]), a(g).attr("width", da), a(g).attr("height", pa), a(g).attr("alt", H[i + 1]), ya()
                    }
                }
                r.onLoaded.call(this);
                var u, f, v, b, _, x = r.rows,
                    k = r.cols,
                    T = 1,
                    L = 0,
                    R = new Array("simpleFade", "curtainTopLeft", "curtainTopRight", "curtainBottomLeft", "curtainBottomRight", "curtainSliceLeft", "curtainSliceRight", "blindCurtainTopLeft", "blindCurtainTopRight", "blindCurtainBottomLeft", "blindCurtainBottomRight", "blindCurtainSliceBottom", "blindCurtainSliceTop", "stampede", "mosaic", "mosaicReverse", "mosaicRandom", "mosaicSpiral", "mosaicSpiralReverse", "topLeftBottomRight", "bottomRightTopLeft", "bottomLeftTopRight", "topRightBottomLeft", "scrollLeft", "scrollRight", "scrollTop", "scrollBottom", "scrollHorz");
                marginLeft = 0, marginTop = 0, opacityOnGrid = 0, 1 == r.opacityOnGrid ? opacityOnGrid = 0 : opacityOnGrid = 1;
                var F = a(" > div", h).eq(i).attr("data-fx");
                if ("random" == (b = fa() && "" != r.mobileFx && "default" != r.mobileFx ? r.mobileFx : void 0 !== F && !1 !== F && "default" !== F ? F : r.fx) ? b = (b = _a(R))[0] : (b = b).indexOf(",") > 0 && (b = (b = _a(b = (b = b.replace(/ /g, "")).split(",")))[0]), dataEasing = a(" > div", h).eq(i).attr("data-easing"), mobileEasing = a(" > div", h).eq(i).attr("data-mobileEasing"), _ = fa() && "" != r.mobileEasing && "default" != r.mobileEasing ? "undefined" != typeof mobileEasing && !1 !== mobileEasing && "default" !== mobileEasing ? mobileEasing : r.mobileEasing : "undefined" != typeof dataEasing && !1 !== dataEasing && "default" !== dataEasing ? dataEasing : r.easing, void 0 !== (u = a(" > div", h).eq(i).attr("data-slideOn")) && !1 !== u) B = u;
                else if ("random" == r.slideOn) {
                    var B = new Array("next", "prev");
                    B = (B = _a(B))[0]
                } else B = r.slideOn;
                var q = a(" > div", h).eq(i).attr("data-time");
                f = void 0 !== q && !1 !== q && "" !== q ? parseFloat(q) : r.time;
                var O = a(" > div", h).eq(i).attr("data-transPeriod");
                switch (v = void 0 !== O && !1 !== O && "" !== O ? parseFloat(O) : r.transPeriod, a(h).hasClass("camerastarted") || ("kenburns" != b && (b = "simpleFade"), B = "next", _ = "", v = 400, a(h).addClass("camerastarted")), b) {
                    case "simpleFade":
                    case "kenburns":
                        k = 1, x = 1;
                        break;
                    case "curtainTopLeft":
                    case "curtainTopRight":
                    case "curtainBottomLeft":
                    case "curtainBottomRight":
                    case "curtainSliceLeft":
                    case "curtainSliceRight":
                        k = 0 == r.slicedCols ? r.cols : r.slicedCols, x = 1;
                        break;
                    case "blindCurtainTopLeft":
                    case "blindCurtainTopRight":
                    case "blindCurtainBottomLeft":
                    case "blindCurtainBottomRight":
                    case "blindCurtainSliceTop":
                    case "blindCurtainSliceBottom":
                        x = 0 == r.slicedRows ? r.rows : r.slicedRows, k = 1;
                        break;
                    case "stampede":
                        L = "-" + v;
                        break;
                    case "mosaic":
                    case "mosaicReverse":
                        L = r.gridDifference;
                        break;
                    case "mosaicRandom":
                        break;
                    case "mosaicSpiral":
                    case "mosaicSpiralReverse":
                        L = r.gridDifference, T = 1.7;
                        break;
                    case "topLeftBottomRight":
                    case "bottomRightTopLeft":
                    case "bottomLeftTopRight":
                    case "topRightBottomLeft":
                        L = r.gridDifference, T = 6;
                        break;
                    case "scrollLeft":
                    case "scrollRight":
                    case "scrollTop":
                    case "scrollBottom":
                    case "scrollHorz":
                        k = 1, x = 1
                }
                for (var W, A, z = 0, E = x * k, G = Y - Math.floor(Y / k) * k, j = $ - Math.floor($ / x) * x, Q = 0, Z = 0, aa = new Array, ta = new Array, ea = new Array; z < E;) {
                    aa.push(z), ta.push(z), P.append('<div class="cameraappended" style="display:none; overflow:hidden; position:absolute; z-index:1000" />');
                    var sa = a(".cameraappended:eq(" + z + ")", d);
                    "scrollLeft" == b || "scrollRight" == b || "scrollTop" == b || "scrollBottom" == b || "scrollHorz" == b ? J.eq(i).clone().show().appendTo(sa) : "kenburns" != b && ("next" == B ? J.eq(i).clone().show().appendTo(sa) : J.eq(e).clone().show().appendTo(sa)), W = z % k < G ? 1 : 0, z % k == 0 && (Q = 0), A = Math.floor(z / k) < j ? 1 : 0, sa.css({
                        height: Math.floor($ / x + A + 1),
                        left: Q,
                        top: Z,
                        width: Math.floor(Y / k + W + 1)
                    }), a("> .cameraSlide", sa).css({
                        height: $,
                        "margin-left": "-" + Q + "px",
                        "margin-top": "-" + Z + "px",
                        width: Y
                    }), Q = Q + sa.width() - 1, z % k == k - 1 && (Z = Z + sa.height() - 1), z++
                }
                switch (b) {
                    case "curtainTopLeft":
                    case "curtainBottomLeft":
                    case "curtainSliceLeft":
                        break;
                    case "curtainTopRight":
                    case "curtainBottomRight":
                    case "curtainSliceRight":
                        aa = aa.reverse();
                        break;
                    case "blindCurtainTopLeft":
                        break;
                    case "blindCurtainBottomLeft":
                        aa = aa.reverse();
                        break;
                    case "blindCurtainSliceTop":
                    case "blindCurtainTopRight":
                        break;
                    case "blindCurtainBottomRight":
                    case "blindCurtainSliceBottom":
                        aa = aa.reverse();
                        break;
                    case "stampede":
                        aa = _a(aa);
                        break;
                    case "mosaic":
                        break;
                    case "mosaicReverse":
                        aa = aa.reverse();
                        break;
                    case "mosaicRandom":
                        aa = _a(aa);
                        break;
                    case "mosaicSpiral":
                        var na = x / 2,
                            ca = 0;
                        for (la = 0; la < na; la++) {
                            for (ma = la, ha = la; ha < k - la - 1; ha++) ea[ca++] = ma * k + ha;
                            for (ha = k - la - 1, ma = la; ma < x - la - 1; ma++) ea[ca++] = ma * k + ha;
                            for (ma = x - la - 1, ha = k - la - 1; ha > la; ha--) ea[ca++] = ma * k + ha;
                            for (ha = la, ma = x - la - 1; ma > la; ma--) ea[ca++] = ma * k + ha
                        }
                        aa = ea;
                        break;
                    case "mosaicSpiralReverse":
                        var la;
                        na = x / 2, ca = E - 1;
                        for (la = 0; la < na; la++) {
                            for (ma = la, ha = la; ha < k - la - 1; ha++) ea[ca--] = ma * k + ha;
                            for (ha = k - la - 1, ma = la; ma < x - la - 1; ma++) ea[ca--] = ma * k + ha;
                            for (ma = x - la - 1, ha = k - la - 1; ha > la; ha--) ea[ca--] = ma * k + ha;
                            for (ha = la, ma = x - la - 1; ma > la; ma--) ea[ca--] = ma * k + ha
                        }
                        aa = ea;
                        break;
                    case "topLeftBottomRight":
                        for (var ma = 0; ma < x; ma++)
                            for (var ha = 0; ha < k; ha++) ea.push(ha + ma);
                        ta = ea;
                        break;
                    case "bottomRightTopLeft":
                        for (ma = 0; ma < x; ma++)
                            for (ha = 0; ha < k; ha++) ea.push(ha + ma);
                        ta = ea.reverse();
                        break;
                    case "bottomLeftTopRight":
                        for (ma = x; ma > 0; ma--)
                            for (ha = 0; ha < k; ha++) ea.push(ha + ma);
                        ta = ea;
                        break;
                    case "topRightBottomLeft":
                        for (ma = 0; ma < x; ma++)
                            for (ha = k; ha > 0; ha--) ea.push(ha + ma);
                        ta = ea
                }
                a.each(aa, function(t, o) {
                    switch (W = o % k < G ? 1 : 0, o % k == 0 && (Q = 0), A = Math.floor(o / k) < j ? 1 : 0, b) {
                        case "simpleFade":
                        case "kenburns":
                            height = $, width = Y, opacityOnGrid = 0;
                            break;
                        case "curtainTopLeft":
                        case "curtainTopRight":
                            height = 0, width = Math.floor(Y / k + W + 1), marginTop = "-" + Math.floor($ / x + A + 1) + "px";
                            break;
                        case "curtainBottomLeft":
                        case "curtainBottomRight":
                            height = 0, width = Math.floor(Y / k + W + 1), marginTop = Math.floor($ / x + A + 1) + "px";
                            break;
                        case "curtainSliceLeft":
                        case "curtainSliceRight":
                            height = 0, width = Math.floor(Y / k + W + 1), marginTop = o % 2 == 0 ? Math.floor($ / x + A + 1) + "px" : "-" + Math.floor($ / x + A + 1) + "px";
                            break;
                        case "blindCurtainTopLeft":
                            height = Math.floor($ / x + A + 1), width = 0, marginLeft = "-" + Math.floor(Y / k + W + 1) + "px";
                            break;
                        case "blindCurtainTopRight":
                            height = Math.floor($ / x + A + 1), width = 0, marginLeft = Math.floor(Y / k + W + 1) + "px";
                            break;
                        case "blindCurtainBottomLeft":
                            height = Math.floor($ / x + A + 1), width = 0, marginLeft = "-" + Math.floor(Y / k + W + 1) + "px";
                            break;
                        case "blindCurtainBottomRight":
                            height = Math.floor($ / x + A + 1), width = 0, marginLeft = Math.floor(Y / k + W + 1) + "px";
                            break;
                        case "blindCurtainSliceBottom":
                        case "blindCurtainSliceTop":
                            height = Math.floor($ / x + A + 1), width = 0, marginLeft = o % 2 == 0 ? "-" + Math.floor(Y / k + W + 1) + "px" : Math.floor(Y / k + W + 1) + "px";
                            break;
                        case "stampede":
                            height = 0, width = 0, marginLeft = .2 * Y * (t % k - (k - Math.floor(k / 2))) + "px", marginTop = .2 * $ * (Math.floor(t / k) + 1 - (x - Math.floor(x / 2))) + "px";
                            break;
                        case "mosaic":
                            height = 0, width = 0;
                            break;
                        case "mosaicReverse":
                            height = 0, width = 0, marginLeft = Math.floor(Y / k + W + 1) + "px", marginTop = Math.floor($ / x + A + 1) + "px";
                            break;
                        case "mosaicRandom":
                        case "mosaicSpiral":
                        case "mosaicSpiralReverse":
                            height = 0, width = 0, marginLeft = .5 * Math.floor(Y / k + W + 1) + "px", marginTop = .5 * Math.floor($ / x + A + 1) + "px";
                            break;
                        case "topLeftBottomRight":
                            height = 0, width = 0;
                            break;
                        case "bottomRightTopLeft":
                            height = 0, width = 0, marginLeft = Math.floor(Y / k + W + 1) + "px", marginTop = Math.floor($ / x + A + 1) + "px";
                            break;
                        case "bottomLeftTopRight":
                            height = 0, width = 0, marginLeft = 0, marginTop = Math.floor($ / x + A + 1) + "px";
                            break;
                        case "topRightBottomLeft":
                            height = 0, width = 0, marginLeft = Math.floor(Y / k + W + 1) + "px", marginTop = 0;
                            break;
                        case "scrollRight":
                            height = $, width = Y, marginLeft = -Y;
                            break;
                        case "scrollLeft":
                            height = $, width = Y, marginLeft = Y;
                            break;
                        case "scrollTop":
                            height = $, width = Y, marginTop = $;
                            break;
                        case "scrollBottom":
                            height = $, width = Y, marginTop = -$;
                            break;
                        case "scrollHorz":
                            height = $, width = Y, marginLeft = 0 == e && i == I - 1 ? -Y : e < i || e == I - 1 && 0 == i ? Y : -Y
                    }
                    var s = a(".cameraappended:eq(" + o + ")", d);
                    void 0 !== D && (clearInterval(D), clearTimeout(N), N = setTimeout(ka, v + L)), a(w).length && (a(".camera_pag li", n).removeClass("cameracurrent"), a(".camera_pag li", n).eq(i).addClass("cameracurrent")), a(y).length && (a("li", y).removeClass("cameracurrent"), a("li", y).eq(i).addClass("cameracurrent"), a("li", y).not(".cameracurrent").find("img").animate({
                        opacity: .5
                    }, 0), a("li.cameracurrent img", y).animate({
                        opacity: 1
                    }, 0), a("li", y).hover(function() {
                        a("img", this).stop(!0, !1).animate({
                            opacity: 1
                        }, 150)
                    }, function() {
                        a(this).hasClass("cameracurrent") || a("img", this).stop(!0, !1).animate({
                            opacity: .5
                        }, 150)
                    }));
                    var p = parseFloat(v) + parseFloat(L);

                    function g() {
                        if (a(this).addClass("cameraeased"), a(".cameraeased", d).length >= 0 && a(y).css({
                                visibility: "visible"
                            }), a(".cameraeased", d).length == E) {
                            xa(), a(".moveFromLeft, .moveFromRight, .moveFromTop, .moveFromBottom, .fadeIn, .fadeFromLeft, .fadeFromRight, .fadeFromTop, .fadeFromBottom", l).each(function() {
                                a(this).css("visibility", "hidden")
                            }), J.eq(i).show().css("z-index", "999").removeClass("cameranext").addClass("cameracurrent"), J.eq(e).css("z-index", "1").removeClass("cameracurrent"), a(".cameraContent", l).eq(i).addClass("cameracurrent"), e >= 0 && a(".cameraContent", l).eq(e).removeClass("cameracurrent"), r.onEndTransition.call(this), "hide" != a("> div", h).eq(i).attr("data-video") && a(".cameraContent.cameracurrent .imgFake", l).length && a(".cameraContent.cameracurrent .imgFake", l).click();
                            var t = J.eq(i).find(".fadeIn").length,
                                o = a(".cameraContent", l).eq(i).find(".moveFromLeft, .moveFromRight, .moveFromTop, .moveFromBottom, .fadeIn, .fadeFromLeft, .fadeFromRight, .fadeFromTop, .fadeFromBottom").length;
                            0 != t && a(".cameraSlide.cameracurrent .fadeIn", l).each(function() {
                                if ("" != a(this).attr("data-easing")) var e = a(this).attr("data-easing");
                                else e = _;
                                var i = a(this);
                                if (void 0 === i.attr("data-outerWidth") || !1 === i.attr("data-outerWidth") || "" === i.attr("data-outerWidth")) {
                                    var r = i.outerWidth();
                                    i.attr("data-outerWidth", r)
                                } else r = i.attr("data-outerWidth");
                                if (void 0 === i.attr("data-outerHeight") || !1 === i.attr("data-outerHeight") || "" === i.attr("data-outerHeight")) {
                                    var o = i.outerHeight();
                                    i.attr("data-outerHeight", o)
                                } else o = i.attr("data-outerHeight");
                                var s = i.position(),
                                    n = (s.left, s.top, i.attr("class")),
                                    c = i.index();
                                i.parents(".camerarelative").outerHeight(), i.parents(".camerarelative").outerWidth(); - 1 != n.indexOf("fadeIn") ? i.animate({
                                    opacity: 0
                                }, 0).css("visibility", "visible").delay(f / t * (.1 * (c - 1))).animate({
                                    opacity: 1
                                }, f / t * .15, e) : i.css("visibility", "visible")
                            }), a(".cameraContent.cameracurrent", l).show(), 0 != o && a(".cameraContent.cameracurrent .moveFromLeft, .cameraContent.cameracurrent .moveFromRight, .cameraContent.cameracurrent .moveFromTop, .cameraContent.cameracurrent .moveFromBottom, .cameraContent.cameracurrent .fadeIn, .cameraContent.cameracurrent .fadeFromLeft, .cameraContent.cameracurrent .fadeFromRight, .cameraContent.cameracurrent .fadeFromTop, .cameraContent.cameracurrent .fadeFromBottom", l).each(function() {
                                if ("" != a(this).attr("data-easing")) var t = a(this).attr("data-easing");
                                else t = _;
                                var e = a(this),
                                    i = e.position(),
                                    r = (i.left, i.top, e.attr("class")),
                                    s = e.index(),
                                    n = e.outerHeight(); - 1 != r.indexOf("moveFromLeft") ? (e.css({
                                    left: "-" + Y + "px",
                                    right: "auto"
                                }), e.css("visibility", "visible").delay(f / o * (.1 * (s - 1))).animate({
                                    left: i.left
                                }, f / o * .15, t)) : -1 != r.indexOf("moveFromRight") ? (e.css({
                                    left: Y + "px",
                                    right: "auto"
                                }), e.css("visibility", "visible").delay(f / o * (.1 * (s - 1))).animate({
                                    left: i.left
                                }, f / o * .15, t)) : -1 != r.indexOf("moveFromTop") ? (e.css({
                                    top: "-" + $ + "px",
                                    bottom: "auto"
                                }), e.css("visibility", "visible").delay(f / o * (.1 * (s - 1))).animate({
                                    top: i.top
                                }, f / o * .15, t, function() {
                                    e.css({
                                        top: "auto",
                                        bottom: 0
                                    })
                                })) : -1 != r.indexOf("moveFromBottom") ? (e.css({
                                    top: $ + "px",
                                    bottom: "auto"
                                }), e.css("visibility", "visible").delay(f / o * (.1 * (s - 1))).animate({
                                    top: i.top
                                }, f / o * .15, t)) : -1 != r.indexOf("fadeFromLeft") ? (e.animate({
                                    opacity: 0
                                }, 0).css({
                                    left: "-" + Y + "px",
                                    right: "auto"
                                }), e.css("visibility", "visible").delay(f / o * (.1 * (s - 1))).animate({
                                    left: i.left,
                                    opacity: 1
                                }, f / o * .15, t)) : -1 != r.indexOf("fadeFromRight") ? (e.animate({
                                    opacity: 0
                                }, 0).css({
                                    left: Y + "px",
                                    right: "auto"
                                }), e.css("visibility", "visible").delay(f / o * (.1 * (s - 1))).animate({
                                    left: i.left,
                                    opacity: 1
                                }, f / o * .15, t)) : -1 != r.indexOf("fadeFromTop") ? (e.animate({
                                    opacity: 0
                                }, 0).css({
                                    top: "-" + $ + "px",
                                    bottom: "auto"
                                }), e.css("visibility", "visible").delay(f / o * (.1 * (s - 1))).animate({
                                    top: i.top,
                                    opacity: 1
                                }, f / o * .15, t, function() {
                                    e.css({
                                        top: "auto",
                                        bottom: 0
                                    })
                                })) : -1 != r.indexOf("fadeFromBottom") ? (e.animate({
                                    opacity: 0
                                }, 0).css({
                                    bottom: "-" + n + "px"
                                }), e.css("visibility", "visible").delay(f / o * (.1 * (s - 1))).animate({
                                    bottom: "0",
                                    opacity: 1
                                }, f / o * .15, t)) : -1 != r.indexOf("fadeIn") ? e.animate({
                                    opacity: 0
                                }, 0).css("visibility", "visible").delay(f / o * (.1 * (s - 1))).animate({
                                    opacity: 1
                                }, f / o * .15, t) : e.css("visibility", "visible")
                            }), a(".cameraappended", d).remove(), h.removeClass("camerasliding"), J.eq(e).hide();
                            var s, n = a(".camera_bar_cont", U).width(),
                                g = a(".camera_bar_cont", U).height();
                            s = "pie" != c ? .05 : .005, a("#" + m).animate({
                                opacity: r.loaderOpacity
                            }, 200), D = setInterval(function() {
                                if (h.hasClass("stopped") && clearInterval(D), "pie" != c) switch (ia <= 1.002 && !h.hasClass("stopped") && !h.hasClass("paused") && !h.hasClass("hovered") ? ia += s : ia <= 1 && (h.hasClass("stopped") || h.hasClass("paused") || h.hasClass("stopped") || h.hasClass("hovered")) ? ia = ia : h.hasClass("stopped") || h.hasClass("paused") || h.hasClass("hovered") || (clearInterval(D), V(), a("#" + m).animate({
                                    opacity: 0
                                }, 200, function() {
                                    clearTimeout(N), N = setTimeout(ka, p), Ca(), r.onStartLoading.call(this)
                                })), K) {
                                    case "leftToRight":
                                        a("#" + m).animate({
                                            right: n - n * ia
                                        }, f * s, "linear");
                                        break;
                                    case "rightToLeft":
                                        a("#" + m).animate({
                                            left: n - n * ia
                                        }, f * s, "linear");
                                        break;
                                    case "topToBottom":
                                    case "bottomToTop":
                                        a("#" + m).animate({
                                            bottom: g - g * ia
                                        }, f * s, "linear")
                                } else ra = ia, oa.clearRect(0, 0, r.pieDiameter, r.pieDiameter), oa.globalCompositeOperation = "destination-over", oa.beginPath(), oa.arc(r.pieDiameter / 2, r.pieDiameter / 2, r.pieDiameter / 2 - r.loaderStroke, 0, 2 * Math.PI, !1), oa.lineWidth = r.loaderStroke, oa.strokeStyle = r.loaderBgColor, oa.stroke(), oa.closePath(), oa.globalCompositeOperation = "source-over", oa.beginPath(), oa.arc(r.pieDiameter / 2, r.pieDiameter / 2, r.pieDiameter / 2 - r.loaderStroke, 0, 2 * Math.PI * ra, !1), oa.lineWidth = r.loaderStroke - 2 * r.loaderPadding, oa.strokeStyle = r.loaderColor, oa.stroke(), oa.closePath(), ia <= 1.002 && !h.hasClass("stopped") && !h.hasClass("paused") && !h.hasClass("hovered") ? ia += s : ia <= 1 && (h.hasClass("stopped") || h.hasClass("paused") || h.hasClass("hovered")) ? ia = ia : h.hasClass("stopped") || h.hasClass("paused") || h.hasClass("hovered") || (clearInterval(D), V(), a("#" + m + ", .camera_canvas_wrap", U).animate({
                                    opacity: 0
                                }, 200, function() {
                                    clearTimeout(N), N = setTimeout(ka, p), Ca(), r.onStartLoading.call(this)
                                }))
                            }, f * s)
                        }
                    }
                    if ("kenburns" != b) "scrollLeft" == b || "scrollRight" == b || "scrollTop" == b || "scrollBottom" == b || "scrollHorz" == b ? (r.onStartTransition.call(this), p = 0, s.delay((v + L) / E * ta[t] * T * .5).css({
                        display: "block",
                        height: height,
                        "margin-left": marginLeft,
                        "margin-top": marginTop,
                        width: width
                    }).animate({
                        height: Math.floor($ / x + A + 1),
                        "margin-top": 0,
                        "margin-left": 0,
                        width: Math.floor(Y / k + W + 1)
                    }, v - L, _, g), J.eq(e).delay((v + L) / E * ta[t] * T * .5).animate({
                        "margin-left": -1 * marginLeft,
                        "margin-top": -1 * marginTop
                    }, v - L, _, function() {
                        a(this).css({
                            "margin-top": 0,
                            "margin-left": 0
                        })
                    })) : (r.onStartTransition.call(this), p = parseFloat(v) + parseFloat(L), "next" == B ? s.delay((v + L) / E * ta[t] * T * .5).css({
                        display: "block",
                        height: height,
                        "margin-left": marginLeft,
                        "margin-top": marginTop,
                        width: width,
                        opacity: opacityOnGrid
                    }).animate({
                        height: Math.floor($ / x + A + 1),
                        "margin-top": 0,
                        "margin-left": 0,
                        opacity: 1,
                        width: Math.floor(Y / k + W + 1)
                    }, v - L, _, g) : (J.eq(i).show().css("z-index", "999").addClass("cameracurrent"), J.eq(e).css("z-index", "1").removeClass("cameracurrent"), a(".cameraContent", l).eq(i).addClass("cameracurrent"), a(".cameraContent", l).eq(e).removeClass("cameracurrent"), s.delay((v + L) / E * ta[t] * T * .5).css({
                        display: "block",
                        height: Math.floor($ / x + A + 1),
                        "margin-top": 0,
                        "margin-left": 0,
                        opacity: 1,
                        width: Math.floor(Y / k + W + 1)
                    }).animate({
                        height: height,
                        "margin-left": marginLeft,
                        "margin-top": marginTop,
                        width: width,
                        opacity: opacityOnGrid
                    }, v - L, _, g)));
                    else {
                        if (r.onStartTransition.call(this), p = 0, s.delay((v + L) / E * ta[t] * T * .5).css({
                                display: "block",
                                "margin-left": marginLeft,
                                "margin-top": marginTop
                            }).animate({
                                "margin-top": 0,
                                "margin-left": 0
                            }, v - L, _, g), Math.random() < .5) var u = "0",
                            C = "auto";
                        else u = "auto", C = "0";
                        if (Math.random() < .5) var R = "0",
                            F = "auto";
                        else R = "auto", F = "0";
                        J.eq(i).css({
                            opacity: "0",
                            display: "block",
                            "z-index": J.eq(e).css("z-index") + 1
                        }).animate({
                            opacity: "1"
                        }, {
                            duration: v - L,
                            easing: "linear",
                            complete: function() {
                                g()
                            },
                            start: function(t, e) {
                                a(this).find("img").stop(!0, !0).css({
                                    width: "100%",
                                    height: "100%",
                                    "margin-top": "0",
                                    "margin-left": "0",
                                    left: u,
                                    right: C,
                                    top: R,
                                    bottom: F
                                }).animate({
                                    width: "130%",
                                    height: "130%"
                                }, 2 * f)
                            }
                        })
                    }
                })
            } else {
                var da, pa, ga = C[i],
                    ua = new Image;
                ua.src = ga, o.css("visibility", "hidden"), o.prepend(a(ua).attr("class", "imgLoaded").css("visibility", "hidden")), a(ua).get(0).complete && "0" != da && "0" != pa && void 0 !== da && !1 !== da && void 0 !== pa && !1 !== pa || (a(".camera_loader", n).delay(500).fadeIn(400), ua.onload = function() {
                    da = ua.naturalWidth, pa = ua.naturalHeight, a(ua).attr("data-alignment", M[i]).attr("data-portrait", S[i]), a(ua).attr("width", da), a(ua).attr("height", pa), a(ua).attr("alt", H[i]), d.find(".cameraSlide_" + i).css("visibility", "visible"), ya(), Ca(i + 1), a(".camera_loader", n).is(":visible") ? a(".camera_loader", n).fadeOut(400) : (a(".camera_loader", n).css({
                        visibility: "hidden"
                    }), a(".camera_loader", n).fadeOut(400, function() {
                        a(".camera_loader", n).css({
                            visibility: "visible"
                        })
                    }))
                })
            }
        }

        function Ta() {
            if (!h.hasClass("camerasliding")) {
                var t = parseFloat(a(".cameraSlide.cameracurrent", d).index());
                clearInterval(D), V(), a("#" + m + ", .camera_canvas_wrap", n).animate({
                    opacity: 0
                }, 0), ka(), Ca(0 != t ? t : I), r.onStartLoading.call(this)
            }
        }

        function La() {
            if (!h.hasClass("camerasliding")) {
                var t = parseFloat(a(".cameraSlide.cameracurrent", d).index());
                clearInterval(D), V(), a("#" + m + ", .camera_canvas_wrap", U).animate({
                    opacity: 0
                }, 0), ka(), Ca(t == I - 1 ? 1 : t + 2), r.onStartLoading.call(this)
            }
        }

        function Ra(a) {
            ca = 0, la = 0, ma = 0, ha = 0, da = 0, 0, 0, 0, 0, 0, ga = null, ua = null, null, null, null
        }
    };
    window.Slideshowck = t
}(jQuery),
function(a) {
    a.fn.cameraStop = function() {
        var t = a(this),
            e = a(".camera_src", t);
        t.index();
        if (e.addClass("stopped"), a(".camera_showcommands").length) a(".camera_thumbs_wrap", t);
        else;
    }
}(jQuery),
function(a) {
    a.fn.cameraPause = function() {
        var t = a(this);
        a(".camera_src", t).addClass("paused")
    }
}(jQuery),
function(a) {
    a.fn.cameraResume = function() {
        var t = a(this),
            e = a(".camera_src", t);
        "undefined" != typeof autoAdv && !0 === autoAdv || e.removeClass("paused")
    }
}(jQuery);